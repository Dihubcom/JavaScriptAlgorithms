function formvalidation()
{
	var uid=document.registration
	var passid=document.registration
	var uname=document.registration
	var uadd=document.registration
	var ucountry=document.registration
	var uzip=document.registration
	var uemail=document.registration
	var umsex=document.registration
	var ufsex=document.registration (userid_validation(uid,512))
	{
		if(passid_validation(pasid,7,12))
	{	
		if(all letter(uname))
	{ 
		if (alphanumeric(uadd))
	{	
		if (countryselect(ucountry))
	{
		if (alphanumeric(uzip))
	{
		if(validateEmail(uemail)
	{
		if (validsex(umsex,ufsex))
	{
	}
	}
	}
	}
	}
	}
	}
	}
return false;
} 
	
function myfunction(){
	var x = document.getElementById("myTopnav");
	if(x.className==="topnav"){
		x.  className +="responsive";

	}else{
		x. className = "topnav";
	}
}