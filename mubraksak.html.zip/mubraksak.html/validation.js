﻿function validate(){
	login=document.getElementById('login');
	
	
	login.addEventListener('fill' if username=15 char, false);
	login.addEventListener('fill' if password<6 char, false);
}
function validateform1(id="")
{
login=document.getElementById('login');
var name=document.step1.name.value;
var password=documment.step1.password.value;
	if (name=="")
		{
			alert=("please fill out this field");
			rturn false;
		}
  else  if(pasword.length<6)
		{
			alert("please enter a valid password");
		{
	end if
}
function validateform2()
{
var phonenumber=document.step1.phonenumber.value;
var email=documment.step1.email.value;
var atposition=x.indexof("@");
var dottposition=x.lastindexof(".");
	if (phonenumber=="")
		{
			alert=("please enter a number);
			rturn false;
		}
  else  if(atpositio<1 || dotposition<atposition+2 || dotposition=2>=x.length)
		{
			alert("please enter a valid email");
		{
	end if
}
/*this is the validation of our form
*therfore this form is validated and all the must important field
*must be fill out before sending to the server
*copyright mubrak abdulkadir*/
